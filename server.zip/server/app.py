# app.py
import os
import bcrypt
from flask import Flask, jsonify, make_response, request, session
from flask_restful import Resource
from extensions import db, migrate, api
from models.user import User
from models.group import Group
from models.member import Member
from models.contribution import Contribution

# Import and register blueprints
from routes.auth import auth_bp
from routes.user import user_bp
from routes.group import group_bp
from routes.member_routes import member_bp
from routes.contribution_routes import contribution_bp

def register_blueprints(app):
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(user_bp, url_prefix='/api/users')
    app.register_blueprint(group_bp, url_prefix='/api/groups')
    app.register_blueprint(member_bp, url_prefix='/api/members')
    app.register_blueprint(contribution_bp, url_prefix='/api/contributions')

# --------- Auth: Register Resource ---------
class Register(Resource):
    def post(self):
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')

        if not all([username, email, password]):
            return make_response(jsonify({"error": "Missing required fields"}), 400)

        try:
            user = User(username=username, email=email, password=password)
            db.session.add(user)
            db.session.commit()
        except ValueError as ve:
            return make_response(jsonify({"error": str(ve)}), 400)

        return make_response(jsonify({"message": "Registration successful!"}), 201)

# --------- Auth: Login Resource ---------
class Login(Resource):
    def post(self):
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')

        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            return make_response(jsonify({"error": "Invalid credentials"}), 401)

        session['user_id'] = user.id
        user.update_last_login()

        return make_response(jsonify({"message": "Login successful"}), 200)

# --------- Protected Contributions Route ---------
class Contributions(Resource):
    def get(self):
        user_id = session.get('user_id')
        if not user_id:
            return make_response(jsonify({"message": "Unauthorized access"}), 401)

        contributions = Contribution.query.filter_by(user_id=user_id).all()
        data = [c.serialize() for c in contributions]
        return make_response(jsonify(data), 200)

# --------- App Factory ---------
def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI', 'sqlite:///chama.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.secret_key = os.urandom(24)

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    api.init_app(app)

    # Register custom API resources
    api.add_resource(Register, '/auth/register')
    api.add_resource(Login, '/auth/login')
    api.add_resource(Contributions, '/contributions')

    # Register Blueprints
    register_blueprints(app)

    return app

# --------- Run Server ---------
if __name__ == '__main__':
    app = create_app()
    app.run(port=5000, debug=True)
